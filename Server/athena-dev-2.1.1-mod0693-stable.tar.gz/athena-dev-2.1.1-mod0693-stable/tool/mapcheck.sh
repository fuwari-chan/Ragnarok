#!/bin/sh
echo "============================================"
echo "=       map server status checker...       ="
echo "============================================"
#cd /home/athena/athena
#./map-server ./conf/map_athena.conf ./conf/battle_athena.conf ./conf/atcommand_athena.conf ./conf/script_athena.conf ./conf/grf-files.txt &
#cd /home/athena/athena/tool
sleep 20

while [ 0 ]
do
	pcpu=` top -n 1| grep map-server | awk '{print $9}' | awk 'BEGIN{FS="."} {print $1}' ` 
	if [ "$pcpu" -gt 80 ];then
		echo "============================================"
		echo "map server is more than 80% (now $pcpu%)"
		echo "============================================"
		ppid=` ps -a | grep map-server | awk '{print $1}' `
		kill $ppid
cd /home/athena/athena/
./map-server ./conf/map_athena.conf ./conf/battle_athena.conf ./conf/atcommand_athena.conf ./conf/script_athena.conf ./conf/grf-files.txt &
cd /home/athena/athena/tool
		sleep 20
	else
		pmapct=` ps -a| grep map-server | wc -l `
		if [ "$pmapct" -eq 0 ];then
			echo "============================================"
			echo "map server is not running..."
			echo "restart map server..."
			echo "============================================"
cd /home/athena/athena
./map-server ./conf/map_athena.conf ./conf/battle_athena.conf ./conf/atcommand_athena.conf ./conf/script_athena.conf ./conf/grf-files.txt &
cd /home/athena/athena/tool
			sleep 20
			#echo "test"
		else
			echo "map server is ok (now $pcpu%)..."
			sleep 5
		fi
	fi
done
